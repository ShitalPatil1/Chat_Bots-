package com.example.android.pokedr;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class UserDetails extends AppCompatActivity {
    TextView t1,t2;
    Button b1;String s1,s2,s3,s4,s5;
    EditText t3,t4,t5,t6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        t1.findViewById(R.id.textView);
        b1.findViewById(R.id.details_submit_btn);
        t2.findViewById(R.id.details_etname);
        t3.findViewById(R.id.details_etage);
        t4.findViewById(R.id.details_etheight);
        t5.findViewById(R.id.details_etweight);
        t6.findViewById(R.id.details_etsex);

        s1=t2.getText().toString();
        s2=t3.getText().toString();
        s3=t4.getText().toString();
        s4=t5.getText().toString();
        s5=t6.getText().toString();

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Name:"+s1+"Age:"+s2+"Sym:"+s3+"Wight:"+s4+"Sex:"+s5,Toast.LENGTH_LONG).show();
               // t1.setText(s1+s2+s3+s4+s5);
            }
        });




    }

}
