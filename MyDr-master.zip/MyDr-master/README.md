Delivering healthcare services via bots can reduce the increasing healthcare costs and improve the quality and effectiveness of healthcare and last but not least we can make healthcare knowledge completely free accessible to everyone globally. A bot, can start a chatting session with patients in an interactive way. A bot can be created to help patients to articulate their symptoms without a human interaction or can be used to suggest a possible diagnosis to a doctor who can then recommend the next suitable medical steps for the patient.

The idea is to design AI powered Medical Assistant which will interact with patients and collect data on these conditions, check symptoms and send medical report to physicians to save physical time. Our Medical Assistant uses Machine Learning to understand patient’s query and select additional questions which it asks to the user to get more detailed patients symptoms.

Also it help alleviate doctor shortages around the world by freeing up physician’s time for more essential tasks than for asking basic symptoms from the patients when she/he arrives at clinic, instead doctor already will have detailed medical report of the patient.

